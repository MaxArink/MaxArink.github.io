using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public interface IInterfaces { }
public interface IObject 
{
    
}
public interface IPhysics
{

}
