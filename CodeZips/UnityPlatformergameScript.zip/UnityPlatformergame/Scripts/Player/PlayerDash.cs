using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[RequireComponent(typeof(GroundCheck))]
public class PlayerDash : MonoBehaviour
{
    private GroundCheck _gc => GetComponent<GroundCheck>();
    private Rigidbody2D _rb => GetComponent<Rigidbody2D>();
    private float _originalGravity => _rb.gravityScale;

    [SerializeField] private float _dashForce = 1f;
    [SerializeField] private float _dashStartBoost = 1f;
    [SerializeField] private float _dashAcceleration = 5f;
    [SerializeField] private float _dashDuration = 1f;
    [SerializeField] private float _dashCooldown = 1f;
    //[SerializeField] private int _dashAmount = 1;

    private bool _canDash = true;
    private bool _hasAirDashed = false;
    private bool _isDashing = false;
    //private float _lastDirection = 1f;
    //private float T_dashTime;
    //private float T_lastDashTime;
    private Vector2 _dashDirection = Vector2.right;
    private Vector2 _lastMoveDirection = Vector2.right;

    //private void Update()
    //{
    //    //if (Input.GetButtonDown("Fire2") && T_canDash)
    //    //{
    //    //    //StartDash();
    //    //}

    //    // Bijhouden welke richting de speler voor het laatst bewoog
    //    float moveInput = Input.GetAxisRaw("Horizontal");
    //    if (moveInput != 0)
    //    {
    //        T_lastDirection = moveInput;
    //    }

    //    if (_gc.IsGrounded() && !T_isDashing)
    //    {
    //        T_canDash = true;
    //        T_hasAirDashed = false;
    //    }

    //    if (Input.GetButtonDown("Fire3") && T_canDash)
    //    {
    //        StartCoroutine(Dash());
    //    }
    //}

    //private void FixedUpdate()
    //{
    //    if (T_isDashing)
    //    {
    //        PerformDash();
    //    }

    //    // **Cooldown afhandelen**
    //    if (!T_canDash && Time.time > T_lastDashTime + _dashCooldown)
    //    {
    //        T_canDash = true;
    //    }
    //}

    //private void StartDash()
    //{
    //    T_isDashing = true;
    //    T_canDash = false;
    //    T_dashTime = Time.time;
    //    T_lastDashTime = Time.time;

    //    // **Dash in de richting waarin de speler zich beweegt**
    //    T_dashDirection = new Vector2(Input.GetAxisRaw("Horizontal"), Input.GetAxisRaw("Vertical")).normalized;
    //    if (T_dashDirection == Vector2.zero)
    //    {
    //        T_dashDirection = new Vector2(transform.localScale.x, 0).normalized; // Dash in kijkrichting als geen input
    //    }

    //    _rb.velocity = Vector2.zero; // Reset snelheid voordat de dash begint
    //}

    //private void PerformDash()
    //{
    //    if (Time.time < T_dashTime + _dashDuration)
    //    {
    //        _rb.AddForce(T_dashDirection * _dashForce, ForceMode2D.Force);
    //    }
    //    else
    //    {
    //        T_isDashing = false;
    //    }
    //}

    //private void Update()
    //{
    //    // **Lees input**
    //    float horizontal = Input.GetAxisRaw("Horizontal");
    //    float vertical = Input.GetAxisRaw("Vertical");

    //    Vector2 inputDirection = new Vector2(horizontal, vertical).normalized;

    //    // **Update laatst bewogen richting**
    //    if (inputDirection != Vector2.zero)
    //    {
    //        _lastMoveDirection = inputDirection; // Opslaan voor default dash richting
    //    }

    //    // **Dash starten als je kan dashen**
    //    if (Input.GetButtonDown("Fire3") && _canDash && (!_hasAirDashed || _gc.IsGrounded()))
    //    {
    //        // **Gebruik input als richting, anders laatste bewegingsrichting**
    //        Vector2 dashDir = inputDirection != Vector2.zero ? inputDirection : _lastMoveDirection;
    //        StartCoroutine(Dash(dashDir));
    //    }

    //    // **Reset air dash als speler landt**
    //    if (_gc.IsGrounded())
    //    {
    //        _hasAirDashed = false;
    //    }
    //}

    //private void FixedUpdate()
    //{
    //    // Houd de snelheid consistent tijdens de dash
    //    if (_isDashing)
    //    {
    //        _rb.velocity = _dashDirection * _dashForce;
    //    }
    //}

    //private IEnumerator Dash(Vector2 direction)
    //{
    //    // Start dash en zet cooldown direct aan
    //    _isDashing = true;
    //    _canDash = false;
    //    _hasAirDashed = !_gc.IsGrounded(); // Zet Air Dash flag aan als je in de lucht bent

    //    // Zet gravity uit en pas snelheid toe
    //    //_rb.gravityScale = 0f;
    //    _dashDirection = direction;

    //    // **Dash effect (tijdens dash duration)**
    //    float dashEndTime = Time.time + _dashDuration;
    //    while (Time.time < dashEndTime)
    //    {
    //        _rb.velocity = _dashDirection * _dashForce;
    //        yield return null;
    //    }

    //    // Stop dash en reset gravity
    //    _isDashing = false;
    //    //_rb.gravityScale = _originalGravity;

    //    // **Cooldown Timer**
    //    yield return new WaitForSeconds(_dashCooldown);
    //    _canDash = true;
    //}

    private void Update()
    {
        // **Lees input**
        float horizontal = Input.GetAxisRaw("Horizontal");
        float vertical = Input.GetAxisRaw("Vertical");

        Vector2 inputDirection = new Vector2(horizontal, vertical).normalized;

        // **Update laatst bewogen richting**
        if (inputDirection != Vector2.zero)
        {
            _lastMoveDirection = inputDirection; // Opslaan voor default dash richting
        }

        // **Dash starten als je kan dashen**
        if (Input.GetButtonDown("Fire3") && _canDash && (!_hasAirDashed || _gc.IsGrounded()))
        {
            // **Gebruik input als richting, anders laatste bewegingsrichting**
            Vector2 dashDir = inputDirection != Vector2.zero ? inputDirection : _lastMoveDirection;
            StartCoroutine(Dash(dashDir));
        }

        // **Reset air dash als speler landt**
        if (_gc.IsGrounded())
        {
            _hasAirDashed = false;
        }
    }

    private IEnumerator Dash(Vector2 direction)
    {
        _isDashing = true;
        _canDash = false;
        _hasAirDashed = !_gc.IsGrounded();

        _rb.gravityScale = 0f;
        _rb.velocity = Vector2.zero; // Reset snelheid

        float dashTime = 0f;

        _rb.AddForce(direction * _dashStartBoost, ForceMode2D.Impulse); // Krachtige start

        while (dashTime < _dashDuration)
        {
            _rb.AddForce(direction * (_dashAcceleration * dashTime), ForceMode2D.Force);
            dashTime += Time.fixedDeltaTime;
            yield return new WaitForFixedUpdate();
        }

        _isDashing = false;
        _rb.gravityScale = _originalGravity;

        yield return new WaitForSeconds(_dashCooldown);
        _canDash = true;
    }
}