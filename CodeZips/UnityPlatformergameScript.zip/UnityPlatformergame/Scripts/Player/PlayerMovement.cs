using System.Collections;
using System.Collections.Generic;
using Unity.VisualScripting;
using UnityEngine;

public class PlayerMovement : MonoBehaviour
{
    private Rigidbody2D _rb = null;
    private GroundCheck _groundCheck = null;
    //private DustEffects dustEffects;
    private Vector2 _moveInput = new Vector2();

    [SerializeField] float _moveSpeed = 1f;
    [SerializeField] float _runSpeed = 2f;
    [SerializeField] float _acceleration = 1f;
    [SerializeField] float _decceleration = 1f;
    [SerializeField] float _velPower = 1f;

    private int _hAcceleration = 0;
    private int _hDecceleration = 0;

    //private bool _facingRight = true;

    private void Awake()
    {
        if (gameObject.GetComponent<Rigidbody2D>() != null) 
            _rb = GetComponent<Rigidbody2D>();
        if (gameObject.GetComponent<GroundCheck>() != null)
            _groundCheck = GetComponent<GroundCheck>();
    }

    private void Start()
    {
        _hAcceleration = (int)_acceleration;
        _hDecceleration = (int)_decceleration;
    }

    private void Update()
    {
        _moveInput.x = Input.GetAxisRaw("Horizontal");

        if (_groundCheck.IsGrounded() != true)
        {
            _acceleration = _hAcceleration * .5f;
            _decceleration = _hDecceleration * .5f;
            return;
        }

        _acceleration = _hAcceleration;
        _decceleration = _hDecceleration;
            


        //if ((_moveInput.x > 0.01f && !_facingRight) || (_moveInput.x < -0.01f && _facingRight))
        //{
        //    //Flip();
        //}
    }

    private void FixedUpdate()
    {
        Move();
    }

    private void Move()
    {
        float targetSpeed = _moveInput.x * _moveSpeed/* * Run()*/;

        float speedDif = targetSpeed - _rb.velocity.x;

        float accelRate = (Mathf.Abs(targetSpeed) > 0.01f) ? _acceleration : _decceleration;
        // Pow =  X^Y
        float movement = Mathf.Pow(Mathf.Abs(speedDif) * accelRate, _velPower) * Mathf.Sign(speedDif);
        _rb.AddForce(movement * Vector2.right);

        //_rb.velocity = new Vector2(_xPos * _mSpeed, _rb.velocity.y);
    }

    //private void Flip()
    //{
    //    //dustEffects.DustTrail();
    //    _facingRight = !_facingRight;
    //    transform.rotation = /*Quaternion.Euler(transform.rotation.x, -transform.rotation.y, transform.rotation.z);*/Quaternion.Euler(0, _facingRight ? 0 : 180, 0);
    //}

    //private float Run()
    //{
    //    if (_isRunning && _groundCheck.IsGrounded())
    //    {
    //        print("Run");
    //        return 2f;
    //    }
    //    return 1f;
    //}
}