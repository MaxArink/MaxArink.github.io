using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerJump : MonoBehaviour
{
    //[SerializeField] private float _jumpHeight = 10f;
    //[SerializeField] private float _holdJumpForce = 10f;
    //private float _currentJumpForce;
    ////float iets = 5f;

    //[SerializeField] private float _buttonTime = 0.2f;
    ////[SerializeField] private float _cancelRate = 100f;

    //[SerializeField] private float _gravityScale = 5f;
    //[SerializeField] private float _fallGravityScale = 15f;

    //private Rigidbody2D rb;

    //private GroundCheck groundCheck;

    //[SerializeField] private int _extraJump = 0;
    //private int _currentJumps;

    //[SerializeField] private float _coyoteTime = 0.2f;
    //private float _coyoteTimeCounter;
    //[SerializeField] private float _jumpBufferTime = 0.2f;
    //private float _jumpBufferCounter;

    //[SerializeField] private float _yClamp = 30f;

    //float _jumpTime;
    //bool _jumping;
    //private bool _holdingJump;
    //bool _jumpCancelled;

    //private void Start()
    //{
    //    rb = GetComponent<Rigidbody2D>();
    //    groundCheck = GetComponent<GroundCheck>();
    //}

    //private void Update()
    //{
    //    if (groundCheck.IsGrounded() && !_jumping)
    //    {
    //        _currentJumps = _extraJump;
    //        _coyoteTimeCounter = _coyoteTime;
    //        //_currentJumpForce = _jumpHeight;
    //    }
    //    else
    //    {
    //        _coyoteTimeCounter -= Time.deltaTime;
    //    }

    //    if (Input.GetButtonDown("Jump")/* && !groundCheck.IsGrounded()*/)
    //    {
    //        _jumpBufferCounter = _jumpBufferTime;
    //    }
    //    else
    //    {
    //        //print(_jumpBufferCounter);
    //        _jumpBufferCounter -= Time.deltaTime;
    //    }

    //    if (/*Input.GetButtonDown("Jump") && */_coyoteTimeCounter > 0f && _jumpBufferCounter > 0f)
    //    {
    //        _currentJumpForce = Jump(_jumpHeight);
    //    }

    //    if (!groundCheck.IsGrounded() && _currentJumps > 0 && Input.GetButtonDown("Jump"))
    //    {
    //        _currentJumps--;
    //        _currentJumpForce = Jump(_jumpHeight * 0.65f);
    //    }

    //    if (_jumping && !groundCheck.IsGrounded())
    //    {
    //        //float velocity = Mathf.SmoothDamp()
    //        //rb.velocity = new Vector2(rb.velocity.x, iets);
    //        //iets -= 0.1f;
    //        //rb.velocity = new Vector2(rb.velocity.x, _currentJumpForce);
    //        //rb.AddForce(Vector2.up * _currentJumpForce, ForceMode2D.Impulse);
    //        rb.AddForce(new Vector2(0f, _currentJumpForce), ForceMode2D.Force);
    //        //rb.Add
    //        _jumpTime += Time.deltaTime;

    //        //if (Input.GetButtonUp("Jump"))
    //        //{
    //        //    _jumpCancelled = true;
    //        //}

    //        //if (_jumpTime > _buttonTime)
    //        //{
    //        //    _jumping = false;
    //        //}
    //    }

    //    if (Input.GetButtonUp("Jump") || _jumpTime > _buttonTime)
    //    {
    //        _jumping = false;
    //    }

    //    if (rb.velocity.y >= 0)
    //    {
    //        rb.gravityScale = _gravityScale;
    //    }
    //    else if (rb.velocity.y < 0)
    //    {
    //        rb.gravityScale = _fallGravityScale;
    //    }
    //}
    //private void Update()
    //{
    //    // Reset coyote time en jumps als je op de grond staat
    //    if (groundCheck.IsGrounded())
    //    {
    //        _currentJumps = _extraJump;
    //        _coyoteTimeCounter = _coyoteTime;
    //        _jumping = false;
    //    }
    //    else
    //    {
    //        _coyoteTimeCounter -= Time.deltaTime;
    //    }

    //    // Jump buffering: Bewaart input zolang de knop ingedrukt is
    //    if (Input.GetButtonDown("Jump"))
    //    {
    //        _jumpBufferCounter = _jumpBufferTime;
    //    }
    //    else if (Input.GetButtonUp("Jump"))
    //    {
    //        _jumpBufferCounter = 0f;
    //    }
    //    else
    //    {
    //        _jumpBufferCounter -= Time.deltaTime;
    //    }

    //    // Springen met jump buffering en coyote time
    //    if (_jumpBufferCounter > 0f && _coyoteTimeCounter > 0f && !_jumping && Input.GetButton("Jump"))
    //    {
    //        _jumpBufferCounter = 0f;
    //        _coyoteTimeCounter = 0f;
    //        Jump(_jumpHeight);
    //    }

    //    // Dubbele sprong
    //    if (!groundCheck.IsGrounded() && _currentJumps > 0 && Input.GetButtonDown("Jump"))
    //    {
    //        _currentJumps--;
    //        Jump(_jumpHeight * 0.8f);
    //    }

    //    // **Stop jump als de knop losgelaten wordt of de tijd om is**
    //    if (Input.GetButtonUp("Jump") || _jumpTime >= _buttonTime)
    //    {
    //        _jumping = false;
    //    }

    //    // **Verander gravity afhankelijk van of je stijgt of daalt**
    //    rb.gravityScale = rb.velocity.y >= 0 ? _gravityScale : _fallGravityScale;
    //}

    //private void FixedUpdate()
    //{
    //    //if (_jumpCancelled && _jumping && rb.velocity.y > 0)
    //    //{
    //    //    print("call");
    //    //    rb.AddForce(Vector2.down * _cancelRate);
    //    //}

    //    //if (rb.velocity.y <= -_yClamp)
    //    //{
    //    //    rb.velocity = new Vector2(rb.velocity.x, -_yClamp);
    //    //}
    //    //else if (rb.velocity.y >= _yClamp)
    //    //{
    //    //    rb.velocity = new Vector2(rb.velocity.x, _yClamp);
    //    //}

    //    if (_jumping && Input.GetButton("Jump") && _jumpTime < _buttonTime)
    //    {
    //        rb.AddForce(Vector2.up * (_holdJumpForce * Time.fixedDeltaTime * 50f), ForceMode2D.Force);
    //        _jumpTime += Time.fixedDeltaTime;
    //    }
    //}

    ////private float Jump(float pJumpHeight)
    ////{

    ////    if (_jumping) 
    ////        return 0f;

    ////    _jumping = true;
    ////    rb.gravityScale = _gravityScale;
    ////    rb.velocity = new Vector2(rb.velocity.x, 0f);

    ////    float jumpForce = Mathf.Sqrt(pJumpHeight * (Physics2D.gravity.y * rb.gravityScale) * -2) * rb.mass;
    ////    rb.AddForce(Vector2.up * jumpForce, ForceMode2D.Impulse);

    ////    //_jumpCancelled = false;
    ////    _jumpTime = 0f;
    ////    _jumpBufferCounter = 0f;

    ////    return jumpForce;
    ////}

    //private void Jump(float pJumpHeight)
    //{
    //    _jumping = true;
    //    _jumpTime = 0f;

    //    rb.velocity = new Vector2(rb.velocity.x, 0f); // Reset verticale snelheid

    //    float jumpForce = Mathf.Sqrt(Mathf.Abs(pJumpHeight * -2 * (Physics2D.gravity.y * rb.gravityScale))) * rb.mass;
    //    rb.AddForce(Vector2.up * jumpForce, ForceMode2D.Impulse);
    //}

    [SerializeField] private float _jumpHeight = 10f;
    [SerializeField] private float _holdJumpForce = 0.5f;
    [SerializeField] private float _maxJumpTime = 0.2f;
    [SerializeField] private float _jumpBufferTime = 0.2f;
    [SerializeField] private float _coyoteTime = 0.2f;
    [SerializeField] private float _gravityScale = 5f;
    [SerializeField] private float _fallGravityScale = 15f;
    [SerializeField] private int _extraJumps = 1;

    private Rigidbody2D rb;
    private GroundCheck groundCheck;

    private float _jumpBufferCounter;
    private float _coyoteTimeCounter;
    private int _remainingJumps;
    private bool _isJumping;
    private bool _holdingJump;
    private float _jumpTime;
    private bool _jumpPressed;

    private bool _isInAir;

    private void Start()
    {
        rb = GetComponent<Rigidbody2D>();
        groundCheck = GetComponent<GroundCheck>();
        _remainingJumps = _extraJumps;  // Zorg ervoor dat extra sprongen goed zijn ingesteld
    }

    private void Update()
    {
        // **Verwerk input (Update is voor input)**
        if (Input.GetButtonDown("Jump"))
        {
            _jumpBufferCounter = _jumpBufferTime;
            _jumpPressed = true;
        }
        else
        {
            _jumpBufferCounter -= Time.deltaTime;
        }

        // **Als de knop ingedrukt is, onthoud dan dat we springen**
        if (Input.GetButton("Jump"))
        {
            _holdingJump = true;
        }
        else
        {
            _holdingJump = false;
        }
    }

    private void FixedUpdate()
    {
        // **Fysica (FixedUpdate is voor fysica)**

        // Reset de coyote time en extra sprongen als je op de grond staat
        if (groundCheck.IsGrounded())
        {
            _coyoteTimeCounter = _coyoteTime;
            _remainingJumps = _extraJumps;
            _isJumping = false;
            _jumpTime = 0f;  // Reset de sprongtijd als de speler de grond raakt
        }
        else
        {
            _coyoteTimeCounter -= Time.fixedDeltaTime;
        }

        // **Springen als de coyoteTime en jumpBuffer actief zijn**
        if (_jumpBufferCounter > 0f && _coyoteTimeCounter > 0f && !_isJumping)
        {
            _jumpBufferCounter = 0f;
            _coyoteTimeCounter = 0f;
            Jump(_jumpHeight);
        }

        if (!groundCheck.IsGrounded() && _remainingJumps > 0 && _jumpPressed)
        {
            _remainingJumps--;
            Jump(_jumpHeight * 0.5f);  // Minder kracht voor de dubbele sprong
        }

        // **Hold Jump (Met constante kracht gedurende de tijd dat de knop wordt ingedrukt)**
        if (_isJumping && _holdingJump && _jumpTime < _maxJumpTime && rb.velocity.y > 0f)
        {
            rb.AddForce(Vector2.up * _holdJumpForce * 50, ForceMode2D.Force);
            _jumpTime += Time.fixedDeltaTime;
        }

        // **Gravity aanpassen afhankelijk van de richting van de snelheid (om natuurlijk vallen te simuleren)**
        _isInAir = !groundCheck.IsGrounded() || _isJumping || rb.velocity.y != 0;

        // **Als de speler op de grond staat, is de gravity 0 - tenzij hij in de lucht is**
        if (!_isInAir)
        {
            rb.gravityScale = 0f;
        }
        else if (rb.velocity.y >= 0)
        {
            rb.gravityScale = _gravityScale;
        }
        else
        {
            rb.gravityScale = _fallGravityScale;
        }
        //rb.gravityScale = rb.velocity.y >= 0 ? _gravityScale : _fallGravityScale;
    }

    //private void FixedUpdate()
    //{
    //    // **Check of de speler in de lucht is**
    //    _isInAir = !groundCheck.IsGrounded() || _isJumping || rb.velocity.y != 0;

    //    // **Als de speler op de grond staat, is de gravity 0 - tenzij hij in de lucht is**
    //    if (!_isInAir)
    //    {
    //        rb.gravityScale = 0f;
    //    }
    //    else if (rb.velocity.y >= 0)
    //    {
    //        rb.gravityScale = _gravityScale;
    //    }
    //    else
    //    {
    //        rb.gravityScale = _fallGravityScale;
    //    }

    //    // **Reset coyote time en extra jumps als je �cht op de grond staat**
    //    if (groundCheck.IsGrounded() && !_isInAir)
    //    {
    //        _coyoteTimeCounter = _coyoteTime;
    //        _remainingJumps = _extraJumps;
    //        _isJumping = false;
    //        _jumpTime = 0f;
    //    }
    //    else
    //    {
    //        _coyoteTimeCounter -= Time.fixedDeltaTime;
    //    }

    //    // **Springen met coyote time en jump buffer**
    //    if (_jumpBufferCounter > 0f && _coyoteTimeCounter > 0f && !_isJumping && _jumpPressed)
    //    {
    //        _jumpBufferCounter = 0f;
    //        _coyoteTimeCounter = 0f;
    //        Jump(_jumpHeight);
    //        _jumpPressed = false;
    //    }

    //    // **Dubbele sprong, zelfs als je valt**
    //    if (_isInAir && _remainingJumps > 0 && _jumpPressed)
    //    {
    //        _remainingJumps--;
    //        Jump(_jumpHeight * 0.8f);
    //        _jumpPressed = false;
    //    }

    //    // **Hold Jump werkt correct**
    //    if (_isJumping && _holdingJump && _jumpTime < _maxJumpTime && rb.velocity.y > 0f)
    //    {
    //        rb.AddForce(Vector2.up * _holdJumpForce, ForceMode2D.Force);
    //        _jumpTime += Time.fixedDeltaTime;
    //    }
    //}

    private void Jump(float jumpHeight)
    {
        _isJumping = true;
        _jumpTime = 0f;
        _jumpPressed = false;
        rb.velocity = new Vector2(rb.velocity.x, 0f); // Reset verticale snelheid

        // Bereken de kracht van de sprong (afhankelijk van de jumpHeight)
        float jumpForce = Mathf.Sqrt(Mathf.Abs(jumpHeight * -2 * (Physics2D.gravity.y * _gravityScale))) * rb.mass;
        rb.AddForce(Vector2.up * jumpForce, ForceMode2D.Impulse);
    }
}
