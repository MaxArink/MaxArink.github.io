using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Enemy : Physics2DObject
{
    [SerializeField] private EntityObject _entityObject;

    void Start()
    {
        
    }
}
