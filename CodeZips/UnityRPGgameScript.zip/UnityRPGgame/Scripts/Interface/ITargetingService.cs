﻿using System.Collections.Generic;

public interface ITargetingService
{
    List<Entity> GetTargets(TargetingType targetingType, Entity user);
}
