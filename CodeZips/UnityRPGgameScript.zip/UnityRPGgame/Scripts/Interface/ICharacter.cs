using System;
using UnityEngine;

public interface ICharacter
{
    //Role Role { get; }
    //void CharacterInfo();
    CharacterSkill BasicSkill();
    CharacterSkill SkillOne();
    CharacterSkill SkillTwo();
}
