﻿using UnityEngine;

public interface IEnemyInput
{
    Vector2 GetMovementInput();
}