using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;

public class BattleManager : MonoBehaviour
{
    public static BattleManager instance { get; private set; }

    public event Action<Entity> OnTurnStarted;
    public event Action<bool> OnBattleOver;

    [SerializeField] private List<Transform> _characterSpawnPoints;
    [SerializeField] private List<Transform> _enemySpawnPoints;

    private List<Character> _playersTeam = new List<Character>();
    private List<Enemy> _enemyTeam = new List<Enemy>();

    public List<Entity> _enemies => _enemyTeam.Cast<Entity>().ToList();
    public List<Entity> _players => _playersTeam.Cast<Entity>().ToList();

    private List<Entity> _turnOrder = new List<Entity>();
    private int _currentTurnIndex = 0;

    private bool _battleStarted = false;
    private bool _battleOver = false;

    private void Awake()
    {
        if (instance != null && instance != this)
        {
            Destroy(gameObject);
            return;
        }
        instance = this;
    }

    private void Start()
    {
        ChallengeData challengeData = GameManager.instance.PendingBattleData;
        if (challengeData != null)
        {
            StartBattle(challengeData);
        }
        else
        {
            Debug.LogWarning("No challenge data set!");
        }
    }

    public void StartBattle(ChallengeData challengeData)
    {
        if (_battleStarted)
        {
            Debug.LogWarning("Battle is already running!");
            return;
        }

        _battleStarted = true;
        _battleOver = false;

        ClearExistingUnits();
        SpawnPlayerTeam();
        SpawnEnemyTeam(challengeData.EnemyLineup);
        InitializeBattle();
    }

    private void ClearExistingUnits()
    {
        foreach (var c in _playersTeam)
        {
            if (c != null) Destroy(c.gameObject);
        }
        foreach (var e in _enemyTeam)
        {
            if (e != null) Destroy(e.gameObject);
        }
        _playersTeam.Clear();
        _enemyTeam.Clear();
        _turnOrder.Clear();
        _currentTurnIndex = 0;
    }

    private void SpawnPlayerTeam()
    {
        var teamLineup = CleanUpTeamLineup(GameManager.instance.TeamLineup);
        for (int i = 0; i < teamLineup.Count; i++)
        {
            EntityData data = teamLineup[i];
            Transform spawnPoint = i < _characterSpawnPoints.Count ? _characterSpawnPoints[i] : _characterSpawnPoints.Last();

            GameObject go = Instantiate(data.Prefab, spawnPoint.position, Quaternion.identity, spawnPoint);
            Character character = go.GetComponent<Character>();
            character.Initialize(data);
            _playersTeam.Add(character);
        }
    }

    private List<EntityData> CleanUpTeamLineup(List<EntityData> team)
    {
        return team.Where(c => c != null).ToList();
    }

    private void SpawnEnemyTeam(List<EntityData> enemyLineup)
    {
        var cleanedList = CleanUpEnemyLineup(enemyLineup);
        for (int i = 0; i < cleanedList.Count; i++)
        {
            EntityData data = cleanedList[i];
            Transform spawnPoint = i < _enemySpawnPoints.Count ? _enemySpawnPoints[i] : _enemySpawnPoints.Last();

            GameObject go = Instantiate(data.Prefab, spawnPoint.position, Quaternion.identity, spawnPoint);
            Enemy enemy = go.GetComponent<Enemy>();
            enemy.Initialize(data);
            _enemyTeam.Add(enemy);
        }
    }

    private List<EntityData> CleanUpEnemyLineup(List<EntityData> enemies)
    {
        return enemies.Where(e => e != null).ToList();
    }

    private void InitializeBattle()
    {
        _turnOrder.Clear();
        _turnOrder.AddRange(_playersTeam.Cast<Entity>());
        _turnOrder.AddRange(_enemyTeam.Cast<Entity>());

        _turnOrder = _turnOrder.OrderByDescending(e => e.Stats.GetStatValue(StatModifier.StatType.Speed)).ToList();
        _currentTurnIndex = 0;
        StartNextTurn();
    }

    private void StartNextTurn()
    {
        if (_battleOver || CheckBattleOver())
            return;

        if (_currentTurnIndex >= _turnOrder.Count)
            _currentTurnIndex = 0;

        Entity current = _turnOrder[_currentTurnIndex];

        Debug.Log($"Turn: {current.name}");

        OnTurnStarted?.Invoke(current);

        if (current is Enemy enemy)
        {
            enemy.PerformAction(); // AI
            EndTurn();
        }
        else if (current is Character character)
        {
            character.PerformAction(); // Player AI (auto for now)
            // Turn end triggered inside PerformAction()
        }
    }

    public void EndTurn()
    {
        if (_battleOver) return;

        _currentTurnIndex++;
        StartCoroutine(DelayNextTurn());
    }

    private IEnumerator DelayNextTurn()
    {
        yield return new WaitForSeconds(0.5f);
        StartNextTurn();
    }

    private bool CheckBattleOver()
    {
        if (_battleOver) return true;

        bool playersAlive = _playersTeam.Any(p => !p.IsDown);
        bool enemiesAlive = _enemyTeam.Any(e => !e.IsDead);

        if (!enemiesAlive)
        {
            Debug.Log("PLAYERS WIN");
            _battleOver = true;
            OnBattleOver?.Invoke(true);
            return true;
        }

        if (!playersAlive)
        {
            Debug.Log("ENEMIES WIN");
            _battleOver = true;
            OnBattleOver?.Invoke(false);
            return true;
        }

        return false;
    }

    // ** TARGETING METHODS met taunt-gewogen selectie **

    public Entity GetRandomAliveEnemy()
    {
        List<Entity> aliveEnemies = _enemyTeam.Where(e => !e.IsDead).Cast<Entity>().ToList();
        return GetWeightedRandomByTaunt(aliveEnemies);
    }

    public Entity GetRandomAliveCharacter()
    {
        List<Entity> aliveCharacters = _playersTeam.Where(c => !c.IsDown).Cast<Entity>().ToList();
        return GetWeightedRandomByTaunt(aliveCharacters);
    }

    private Entity GetWeightedRandomByTaunt(List<Entity> entities)
    {
        if (entities.Count == 0) return null;

        float totalTaunt = entities.Sum(e => e.Role.Taunt);
        if (totalTaunt <= 0)
            totalTaunt = entities.Count; // fallback

        float rand = UnityEngine.Random.Range(0f, totalTaunt);
        float cumulative = 0f;

        foreach (Entity entity in entities)
        {
            float weight = entity.Role.Taunt > 0 ? entity.Role.Taunt : 1f;
            cumulative += weight;
            if (rand <= cumulative)
                return entity;
        }

        return entities[0]; // fallback
    }

    public Entity GetFirstAliveEnemy()
    {
        return _enemyTeam.FirstOrDefault(e => !e.IsDead);
    }

    public Entity GetFirstAliveAlly()
    {
        return _playersTeam.FirstOrDefault(c => !c.IsDown);
    }

    // Register methods als je ze nodig hebt (bijv. voor runtime aanmaken)
    public void RegisterCharacter(Character c) => _playersTeam.Add(c);
    public void RegisterEnemy(Enemy e) => _enemyTeam.Add(e);
}
