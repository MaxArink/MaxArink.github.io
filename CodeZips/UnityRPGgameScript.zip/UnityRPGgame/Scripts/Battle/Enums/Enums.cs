public enum SkillType { Damage, Heal, Buff }
public enum TargetType { SingleEnemy, SplashEnemy, AOEEnemy, SingleAlly, SplashAlly, AOEAlly, Self }
public enum TargetingType { SingleTarget, Splash, AOE, Self }