﻿using System.Collections.Generic;
using System;

public class CharacterSkill
{
    public string Name;
    public TargetingType Targeting;
    public Action<List<Entity>> Execute;

    public CharacterSkill(string pName, TargetingType pTargeting, Action<List<Entity>> pExecute)
    {
        Name = pName;
        Targeting = pTargeting;
        Execute = pExecute;
    }
}

