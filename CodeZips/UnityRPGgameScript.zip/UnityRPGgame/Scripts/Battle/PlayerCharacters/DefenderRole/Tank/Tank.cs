using System.Linq;
using UnityEngine;

public class Tank : MonoBehaviour, ICharacter
{
    private Character _character => GetComponent<Character>();

    private float _def => _character.Stats.GetStatValue(StatModifier.StatType.Def);

    public CharacterSkill BasicSkill()
    {
        return new CharacterSkill(
            "Shield Bash",
            TargetingType.SingleTarget,
            pTargets =>
            {
                if (pTargets.Count > 0 && pTargets[0] is Enemy enemy)
                {
                    enemy.TakeDamage(_def * 0.6f);
                    Debug.Log($"{_character.name} slaat {enemy.name} voor {_def} schade.");
                }
            });
    }

    public CharacterSkill SkillOne()
    {
        return new CharacterSkill(
            "Slash",
            TargetingType.Self,
            pTargets =>
            {
                
            });
    }

    public CharacterSkill SkillTwo()
    {
        return new CharacterSkill(
            "Bigger Slash",
            TargetingType.AOE,
            targets =>
            {
                
            });
    }
}
