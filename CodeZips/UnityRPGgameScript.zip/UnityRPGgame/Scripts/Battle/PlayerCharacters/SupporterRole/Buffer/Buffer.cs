using System.Linq;
using UnityEngine;

public class Buffer : MonoBehaviour, ICharacter
{
    private Character _character => GetComponent<Character>();

    private float _atk => _character.Stats.GetStatValue(StatModifier.StatType.Atk);

    public CharacterSkill BasicSkill()
    {
        return new CharacterSkill(
            "Wack",
            TargetingType.SingleTarget,
            targets =>
            {
                if (targets.Count > 0 && targets[0] is Enemy enemy)
                {
                    enemy.TakeDamage(_atk * 0.6f);
                    Debug.Log($"{_character.name} slaat {enemy.name} voor {_atk} schade.");
                }
            });
    }

    public CharacterSkill SkillOne()
    {
        return new CharacterSkill(
            "Slash",
            TargetingType.SingleTarget,
            targets =>
            {
                Debug.Log($"unimplemented");
            });
    }

    public CharacterSkill SkillTwo()
    {
        return new CharacterSkill(
            "Bigger Slash",
            TargetingType.AOE,
            targets =>
            {
                Debug.Log($"unimplemented");
            });
    }
}
