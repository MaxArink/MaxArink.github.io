using UnityEngine;
using System;
using System.Linq;

public class Cleric : MonoBehaviour, ICharacter
{
    private Character _character => GetComponent<Character>();

    private float _hp => _character.Stats.GetStatValue(StatModifier.StatType.Hp);

    public CharacterSkill BasicSkill()
    {
        return new CharacterSkill(
            "Whack",
            TargetingType.SingleTarget,
            targets =>
            {
                if (targets.Count > 0 && targets[0] is Enemy enemy)
                {
                    enemy.TakeDamage(_hp * 0.3f);
                    Debug.Log($"{_character.name} slaat {enemy.name} voor {_hp} schade.");
                }
            });
    }

    public CharacterSkill SkillOne()
    {
        return new CharacterSkill(
            "Slash",
            TargetingType.SingleTarget,
            targets =>
            {
                
            });
    }

    public CharacterSkill SkillTwo()
    {
        return new CharacterSkill(
            "Bigger Slash",
            TargetingType.AOE,
            targets =>
            {
                
            });
    }
}
