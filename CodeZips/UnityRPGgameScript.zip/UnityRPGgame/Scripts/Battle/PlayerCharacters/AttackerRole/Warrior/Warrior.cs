using System.Collections.Generic;
using System.Linq;
using UnityEngine;

public class Warrior : MonoBehaviour, ICharacter
{
    private Character _character => GetComponent<Character>();

    private float _atk => _character.Stats.GetStatValue(StatModifier.StatType.Atk);

    public CharacterSkill BasicSkill()
    {
        return new CharacterSkill(
            "Strike",
            TargetingType.SingleTarget,
            targets =>
            {
                if (targets.Count > 0 && targets[0] is Enemy enemy)
                {
                    enemy.TakeDamage(_atk * 0.6f);
                    Debug.Log($"{_character.name} slaat {enemy.name} voor {_atk} schade.");
                }
            });
    }

    public CharacterSkill SkillOne()
    {
        return new CharacterSkill(
            "Slash",
            TargetingType.Splash,
            targets =>
            {
                foreach (Enemy t in targets.OfType<Enemy>())
                {
                    t.TakeDamage(_atk * 0.60f);
                    Debug.Log($"{_character.name} raakt {t.name} met Slash.");
                }
            });
    }

    public CharacterSkill SkillTwo()
    {
        return new CharacterSkill(
            "Bigger Slash",
            TargetingType.Splash,
            targets =>
            {
                foreach (Enemy t in targets.OfType<Enemy>())
                {
                    t.TakeDamage(_atk * 1f);
                    Debug.Log($"{_character.name} raakt {t.name} met Bigger Slash.");
                }
            });
    }
}
