using System.Linq;
using UnityEngine;
using UnityEngine.TextCore.Text;

public class Archer : MonoBehaviour, ICharacter
{
    private Character _character => GetComponent<Character>();
    
    private float _atk => _character.Stats.GetStatValue(StatModifier.StatType.Atk);

    public CharacterSkill BasicSkill()
    {
        return new CharacterSkill(
            "Shot",
            TargetingType.SingleTarget,
            targets =>
            {
                if (targets.Count > 0 && targets[0] is Enemy enemy)
                {
                    enemy.TakeDamage(_atk * 0.6f);
                    Debug.Log($"{_character.name} slaat {enemy.name} voor {_atk} schade.");
                }
            });
    }

    public CharacterSkill SkillOne()
    {
        return new CharacterSkill(
            "Chrage up",
            TargetingType.Self,
            targets =>
            {
                StatModifier atkBuff = new StatModifier(
                    StatModifier.StatType.Atk,
                    25f,
                    3,
                    true
                );

                _character.Stats.AddModifier(atkBuff);

                Debug.Log($"{_character.name} buffs their ATK by 25% for 2 turns!");
            });
    }

    public CharacterSkill SkillTwo()
    {
        return new CharacterSkill(
            "Arrow Drill",
            TargetingType.SingleTarget,
            targets =>
            {
                float atk = _character.Stats.GetStatValue(StatModifier.StatType.Atk);
                foreach (Enemy t in targets.OfType<Enemy>())
                {
                    t.TakeDamage(atk * 1f);
                    Debug.Log($"{_character.name} raakt {t.name} met Arrow Drill.");
                }
            });
    }
}
