﻿using System.Collections.Generic;
using UnityEngine;

public class Entity : MonoBehaviour
{
    [SerializeField] protected BaseStats _baseStats;
    [SerializeField] protected EntityStats _characterStats = null;
    [SerializeField] protected Role _role = null;
    [SerializeField] protected List<Skill> _skills;

    protected StatCalculator _stats;
    protected float _currentHp;

    public StatCalculator Stats => _stats;
    public IReadOnlyList<Skill> Skills => _skills;
    
    public BaseStats BaseStats => _baseStats;
    public EntityStats CharacterStats => _characterStats;
    public Role Role => _role;

    //// Level tijdelijk nog maar niet gebruiken: 29-5-2025
    //[SerializeField] private int _level = 1;
    //public int Level { get => _level; protected set => _level = value; }

    protected virtual void Awake()
    {
        _stats = new StatCalculator(_baseStats);

        _currentHp = _stats.GetStatValue(StatModifier.StatType.Hp);
    }

    public void Initialize(EntityData pData)
    {
        _baseStats = pData.BaseStats;
        _characterStats = pData.EntityStats;
        _role = pData.Role;
        name = pData.name;
    }

    public virtual void PerformAction()
    {
        //Skill skill = _skills[0];
        //ExecuteSkill(skill);
        //Debug.Log($"{name} Doet iets");
        BattleManager.instance.EndTurn();
    }

    //protected virtual void ExecuteSkill(Skill skill)
    //{
    //    switch (skill.TargetType)
    //    {
    //        case TargetType.SingleEnemy:
    //            var enemy = BattleManager.instance.GetFirstAliveEnemy();
    //            if (enemy != null && skill.SkillType == SkillType.Damage)
    //                enemy.TakeDamage(CalculateDamage(skill.Power));
    //            break;

    //        case TargetType.AOEEnemy:
    //            foreach (var e in BattleManager.instance.GetAliveEnemies())
    //            {
    //                if (skill.SkillType == SkillType.Damage)
    //                    e.TakeDamage(CalculateDamage(skill.Power));
    //            }
    //            break;

    //        case TargetType.SingleAlly:
    //            var ally = BattleManager.instance.GetFirstAliveCharacter(); // of een andere logica
    //            if (ally != null && skill.SkillType == SkillType.Heal)
    //                ally.Heal(skill.Power);
    //            break;

    //        case TargetType.Self:
    //            if (skill.SkillType == SkillType.Buff && skill.BuffType.HasValue)
    //                Stats.AddModifier(skill.BuffType.Value, skill.BuffAmount);
    //            break;

    //            // Voeg hier Splash & AOEAllies en meer toe
    //    }
    //}

    protected float CalculateDamage(float basePower)
    {
        float atk = Stats.GetStatValue(StatModifier.StatType.Atk);
        return atk * basePower;
    }

    // Maak de methode virtual
    public virtual void TakeDamage(float pRawDamage)
    {
        float def = _stats.GetStatValue(StatModifier.StatType.Def);

        float flatDmgReduction = Mathf.Floor(def / 5);
        float damage = Mathf.Max(pRawDamage -  flatDmgReduction, 1f);
        _currentHp -= damage;

        Debug.Log($"{name} takes {damage} damage, HP left: {_currentHp}");

        if (_currentHp <= 0)
            Die();
    }

    protected virtual void Die()
    {
        Debug.Log($"{name} died.");
        // Standaard dood-logica
    }
}
