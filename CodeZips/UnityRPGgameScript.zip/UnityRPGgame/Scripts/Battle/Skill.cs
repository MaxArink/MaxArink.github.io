using UnityEngine;

[System.Serializable]
public class Skill
{
    public string Name;
    public SkillType SkillType;
    public TargetType TargetType;
    public float Power; // kan attack, heal, of buff waarde zijn
    public float Range; // voor splash
    public StatModifier.StatType? BuffType; // voor buffs
    public float BuffAmount; // bijv. +10 def
}
