﻿using System.Collections.Generic;
using UnityEngine;

public class TargetingService : ITargetingService
{
    private BattleManager _battleManager;

    public TargetingService(BattleManager pBattleManager)
    {
        _battleManager = pBattleManager;
    }

    public List<Entity> GetTargets(TargetingType pTargetingType, Entity pUser)
    {
        switch (pTargetingType)
        {
            case TargetingType.Self:
                return new List<Entity> { pUser };

            case TargetingType.SingleTarget:
                Entity enemy = _battleManager.GetFirstAliveEnemy();
                return enemy != null ? new List<Entity> { enemy } : new List<Entity>();

            case TargetingType.Splash:
                return new List<Entity> { pUser };

            case TargetingType.AOE:
                //return _battleManager.GetAliveEnemies();
                return new List<Entity>();

            //case TargetingType.Allies:
            //    //return _battleManager.GetAliveCharacters();
            //    return new List<Entity>();

            default:
                Debug.LogWarning("Unsupported targeting type: " + pTargetingType);
                return new List<Entity>();
        }
    }
}