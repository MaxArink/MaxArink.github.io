using UnityEngine;

public class SettingsMenu : MonoBehaviour
{

    public void Settings()
    {

    }
}
