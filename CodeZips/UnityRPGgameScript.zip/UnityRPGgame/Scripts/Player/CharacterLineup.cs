using UnityEngine;

public class CharacterLineup : MonoBehaviour
{
    private ICharacter _character;

    
}
