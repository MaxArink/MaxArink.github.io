﻿namespace System.Runtime.CompilerServices
{
    /// <summary>
    /// Word niet meer gebruikt - Max
    /// </summary>
    internal static class IsExternalInit { }
}