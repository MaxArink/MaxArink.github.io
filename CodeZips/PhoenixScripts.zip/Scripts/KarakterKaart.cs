﻿using System.Collections.Generic;
using UnityEngine;

public class KarakterKaart : MonoBehaviour
{
    private string _personageName = "(Insert Name Here:)";
    private bool _isDead = false;
    public Dictionary<string, int> Vaardigheidskaarten { get; set; } = new Dictionary<string, int>
    {
        { "leervermogen", 0 },
        { "kapitaal", 0 },
        { "aanpassingsvermogen", 0 },
        { "gereedschap", 0 },
        { "sociaal", 0 }
    };
}