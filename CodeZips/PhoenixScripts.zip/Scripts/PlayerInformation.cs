﻿using System.Collections.Generic;

public class PlayerInformation
{
    //code voor de informatie belangerijk voor de speler
    private string _name = "";

    private int _score = 0;
    private bool _turn = false;

    private List<Character> _characterCards = new List<Character>();

    public string Name
    {
        get => _name;
        set => _name = value;
    }

    public int Score
    {
        get => _score;
        set => _score = value;
    }

    public bool Turn
    {
        get => _turn;
        set => _turn = value;
    }

    public List<Character> CharacterCards
    {
        get => _characterCards;
        set => _characterCards = value;
    }
}