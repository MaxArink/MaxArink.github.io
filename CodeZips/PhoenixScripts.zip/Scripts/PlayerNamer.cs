using TMPro;
using UnityEngine;

public class PlayerNamer : MonoBehaviour
{
    private TMP_InputField _inputField => GetComponent<TMP_InputField>();
    private int _numPlayer = 0;

    public int NumPlayer
    {
        get => _numPlayer;
        set => _numPlayer = value;
    }

    public void Start()
    {
        LoadInputText();
    }

    public void SaveInputText()
    {
        //GameManager.instance.PlayerNames[NumPlayer] = _inputField.text;
        GameManager.instance.PlayerInfo[NumPlayer].Name = _inputField.text;
        //LoadInputText();
    }

    public void LoadInputText()
    {
        _inputField.text = GameManager.instance.PlayerInfo[NumPlayer].Name;
    }
}