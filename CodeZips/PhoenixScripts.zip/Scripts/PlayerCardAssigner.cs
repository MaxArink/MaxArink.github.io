﻿using UnityEngine;

public class PlayerCardAssigner : MonoBehaviour
{
    [SerializeField] private CharacterUI _characterPrefab = null;
    [SerializeField] private Transform _spawnPos = null;

    private bool[] _isCharacterAtIndexInGame = new bool[0]; // ik weet dat dit niet heel netjes is -koen

    private void Start()
    {
        PerPlayerGamePreperation();
    }

    public void PerPlayerGamePreperation()
    {
        for (int i = 0; i < GameManager.instance.PlayerAmount; i++)
        {
            CreateCharacterCards(i);
        }
    }

    private void CreateCharacterCards(int pPlayerIndex)
    {
        for (int i = 0; i < 3; i++)
        {
            GameManager.instance.PlayerInfo[pPlayerIndex].CharacterCards.Add(InstantiateCharacter());
        }

        foreach (Character card in GameManager.instance.PlayerInfo[pPlayerIndex].CharacterCards)
            Debug.Log($"{card}");
    }

    private Character InstantiateCharacter()
    {
        bool UniqueCharacterSelected = true;

        CharacterUI characterUI = Instantiate(_characterPrefab, _spawnPos);
        Character newCharacter = characterUI.GetComponent<Character>();

        do
        {
            int index = Random.Range(0, 19);
            UniqueCharacterSelected = _isCharacterAtIndexInGame[index];
            _isCharacterAtIndexInGame[index] = false;
        }
        while (UniqueCharacterSelected);

        return newCharacter;
    }
}