﻿using System;
using System.Collections.Generic;
using UnityEditor;
using UnityEngine;

public class GameManager : MonoBehaviour
{
    /// <summary>
    /// instance is the important info for the GameManager
    /// </summary>
    public static GameManager instance { get; private set; }

    [SerializeField] private int _minPlayers = 2;
    [SerializeField] private int _maxPlayers = 5;

    private int _playerAmount = 0;
    
    //private string[] _playerNames = new string[] { "", "", "", "", "" };
    private List<PlayerInformation> _playerInfo = new List<PlayerInformation>();

    /// <summary>
    /// Player Amount wordt geclampt tussen de variablen _minPlayers en _maxPlayers spelers.
    /// </summary>
    public int PlayerAmount
    {
        get => _playerAmount = Mathf.Clamp(_playerAmount, _minPlayers, _maxPlayers);
        set => _playerAmount = Mathf.Clamp(value, _minPlayers, _maxPlayers);
    }

    //public string[] PlayerNames
    //{
    //    get => _playerNames;
    //    set => _playerNames = value;
    //}

    /// <summary>
    /// Clear de List elke keer als die aangeroepen wordt 
    /// </summary>
    public List<PlayerInformation> PlayerInfo
    {
        get => _playerInfo;
        set => _playerInfo = value;
       /* set { _playerInfo.Clear(); _playerInfo = value ?? new List<PlayerInformation>(); }*/
    }


    private void Awake()
    {
        if (instance != null && instance != this)
        {
            Destroy(gameObject);
            return;
        }

        instance = this;
        DontDestroyOnLoad(gameObject);
    }

    private void Start()
    {
        //Array.Resize(ref _playerNames, _maxPlayers);
    }

    /// <summary>
    /// Method that exits the game when it is a build and stops playmode when in the UNITY_EDITOR
    /// </summary>
    public void ExitGame()
    {
        #if UNITY_EDITOR
        EditorApplication.isPlaying = false;
        #endif
        Application.Quit();
    }
}