using TMPro;
using UnityEngine;
using UnityEngine.UI;
using System.Collections.Generic;

public class PlayerSelect : MonoBehaviour
{
    [SerializeField] private TextMeshProUGUI _mText = null;
    [SerializeField] private Button _startButton = null;
    //[SerializeField] private CreatePlayers _createPlayers = null;

    [SerializeField] private PlayerNamer _playerNamePrefab = null;
    [SerializeField] private Transform _containerPos = null;

    private List<PlayerNamer> _spawnedClones = new List<PlayerNamer>();

    private int _previousPlayerAmount = 0;
    private bool _isPlayerAmountDifferent = false;

    //private void Awake()
    //{
    //    _previousPlayerAmount = GameManager.instance.PlayerAmount;
    //}

    private void Start()
    {
        _mText.text = GameManager.instance.PlayerAmount.ToString();
        CreatePlayer();
        // if not all players have a name disable start button
        CanStart();
    }

    private void FixedUpdate()
    {
        if (_previousPlayerAmount == GameManager.instance.PlayerAmount)
        {
            _previousPlayerAmount = GameManager.instance.PlayerAmount;
            _isPlayerAmountDifferent = true;
        }

        CanStart();
    }

    private void CanStart()
    {
        for (int i = 0; i < _spawnedClones.Count; i++)
        {
            if (GameManager.instance.PlayerInfo[i].Name.Length < 2)
            {
                _startButton.gameObject.SetActive(false);
                return;
            }
        }
        _startButton.gameObject.SetActive(true);
    }

    public void AddPlayer()
    {
        GameManager.instance.PlayerAmount++;
        _mText.text = GameManager.instance.PlayerAmount.ToString();
        CreatePlayer();
    }

    public void RemovePlayer()
    { 
        GameManager.instance.PlayerAmount--;
        _mText.text = GameManager.instance.PlayerAmount.ToString();
        CreatePlayer();
    }

    private void CreatePlayer()
    {
        DestroyPlayer();

        for (int i = 0; i < GameManager.instance.PlayerAmount; i++)
        {
            PlayerInformation newPlayer = new PlayerInformation();
            GameManager.instance.PlayerInfo.Add(newPlayer);
            PlayerNamer playersPrefab = Instantiate(_playerNamePrefab, _containerPos);
            playersPrefab.NumPlayer = i;
            _spawnedClones.Add(playersPrefab);
        }
    }

    private void DestroyPlayer()
    {
        foreach (PlayerNamer clone in _spawnedClones)
        {
            Destroy(clone.gameObject);
        }
        if (_isPlayerAmountDifferent == true)
            GameManager.instance.PlayerInfo.RemoveAt(GameManager.instance.PlayerAmount+1);
        _spawnedClones.Clear();
        _isPlayerAmountDifferent = false;
    }
}