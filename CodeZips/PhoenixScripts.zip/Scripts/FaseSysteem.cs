using System;
using System.Collections.Generic;
using UnityEngine;

public class FaseSysteem : MonoBehaviour
{
    public enum Phase
    {
        Achterhoek,
        Overtocht,
        Amerika,
        None
    }

    public event Action OnPhaseChanged;

    [SerializeField] private Phase _currentPhase = Phase.None;

    private Phase[] _usedPhases;

    private Dictionary<Phase, IFase> _faseLogicaMap;
    private IFase _activeLogica;

    private void Awake()
    {
        _faseLogicaMap = new Dictionary<Phase, IFase>
        {
            { Phase.Achterhoek, new AchterhoekSysteem() },
            { Phase.Overtocht, new OvertochtSysteem() },
            { Phase.Amerika, new AmerikaSysteem() }
        };

        List<Phase> fases = new List<Phase>();
        foreach (Phase fase in Enum.GetValues(typeof(Phase)))
        {
            if (fase != Phase.None)
            {
                fases.Add(fase);
            }
        }
        _usedPhases = fases.ToArray();
    }

    private void Start()
    {
        SetPhase(_currentPhase);
    }

    private void Update()
    {
        _activeLogica?.UpdateFase();
    }

    public void SetPhase(Phase pNewPhase)
    {
        _activeLogica?.ExitFase();

        _currentPhase = pNewPhase;

        if (_faseLogicaMap.TryGetValue(_currentPhase, out IFase newLogica)) {
            _activeLogica = newLogica;
            _activeLogica?.EnterFase();
        } else {
            _activeLogica = null;
            Debug.Log("Geen logica voor deze fase.");
        }
    }

    public void NextPhase()
    {
        int index = Array.IndexOf(_usedPhases, _currentPhase);
        index = (index + 1) % _usedPhases.Length;

        OnPhaseChanged?.Invoke();

        SetPhase(_usedPhases[index]);
    }

    public Phase GetCurrentPhase()
    {
        return _currentPhase;
    }
}

public class AchterhoekSysteem : IFase
{
    public void EnterFase()
    {

    }

    public void UpdateFase()
    {
        
    }
    
    public void ExitFase()
    {

    }
}

public class OvertochtSysteem : IFase
{
    public void EnterFase()
    {

    }

    public void UpdateFase()
    {

    }

    public void ExitFase()
    {

    }
}

public class AmerikaSysteem : IFase
{
    public void EnterFase()
    {

    }

    public void UpdateFase()
    {

    }

    public void ExitFase()
    {

    }
}

public interface IFase
{
    void EnterFase();
    void UpdateFase();
    void ExitFase();
}