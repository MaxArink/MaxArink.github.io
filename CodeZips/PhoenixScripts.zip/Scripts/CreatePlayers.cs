using System.Collections.Generic;
using TMPro;
using Unity.VisualScripting;
using UnityEngine;
//using UnityEngine.Events;

/// <summary>
/// N.v.t.
/// </summary>
public class CreatePlayers : MonoBehaviour
{
    [SerializeField] private GameObject _playerNamePrefab = null;
    private List<GameObject> spawnedClones = new List<GameObject>();

    public void CreatePlayer()
    {
        DestroyPlayer();
        
        for (int i = 1; i <= GameManager.instance.PlayerAmount; i++)
        {
            GameObject _playersPrefab = Instantiate(_playerNamePrefab, gameObject.transform);
            spawnedClones.Add(_playersPrefab);
        }
    }

    private void DestroyPlayer()
    {
        foreach (GameObject clone in spawnedClones)
        {
            Destroy(clone);
        }
        spawnedClones.Clear();
    }
}