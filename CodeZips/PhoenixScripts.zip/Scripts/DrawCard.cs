﻿using UnityEngine;
using UnityEngine.UI;

public class DrawCard : MonoBehaviour
{
    [SerializeField] private Button _drawCardButton = null;
    [SerializeField] private GameObject _card = null;

    private void Start()
    {
        _card.SetActive(false);
    }

    private void Update()
    {
        
    }

    public void PakKaart()
    {
        _card.SetActive(true);
        _drawCardButton.gameObject.SetActive(false);
    }
}