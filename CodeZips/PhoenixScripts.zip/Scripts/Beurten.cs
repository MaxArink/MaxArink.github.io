using TMPro;
using UnityEngine;
using System.Collections.Generic;
using UnityEngine.SceneManagement;
using UnityEngine.Rendering;
using System;
using UnityEngine.UI;

public class Beurten : MonoBehaviour
{
    public event Action OnTurnChanged;

    [SerializeField] private TextMeshProUGUI _mText = null;
    [SerializeField] private Button switchTurnsButton; 
    [SerializeField] private GameObject cardManager; 

    private int _spelerBeurt = 0;

    private void Start()
    {
        // Set first player's turn to true at game start
        if (GameManager.instance.PlayerInfo.Count > 0)
        {
            GameManager.instance.PlayerInfo[0].Turn = true;
        }

        DisplayPlayerTurn();

        switchTurnsButton.onClick.AddListener(OnSwitchTurnsButtonClicked);
    }

    private void DisplayPlayerTurn()
    {
        _mText.text = $"{GameManager.instance.PlayerInfo[_spelerBeurt].Name}";
    }
     
    public void NextTurn()
    {
        if (GameManager.instance.PlayerInfo.Count == 0)
            return;

        // Zet eerst de turn van de nu active player op false en daarna verander de speler naar de volgende in de dictionary en zet zijn turn op true
        GameManager.instance.PlayerInfo[_spelerBeurt].Turn = false;
        _spelerBeurt = (_spelerBeurt + 1 != GameManager.instance.PlayerAmount) ? _spelerBeurt + 1 : 0;
        GameManager.instance.PlayerInfo[_spelerBeurt].Turn = true;

        foreach (PlayerInformation player in GameManager.instance.PlayerInfo)
        {
            Debug.Log($"{player.Name}, Turn:{player.Turn}");
        }

        DisplayPlayerTurn();
    }

    public void Continue()
    {
        // idee verander naar event zodat de script niet verplicht zijn - is gedaan Max
        OnTurnChanged?.Invoke();
        OnSwitchTurnsButtonClicked();
        NextTurn();
        //_trade.UpdateTradeDropdown();
        //_countdown.SetRoundTimer();
    }

    private void OnSwitchTurnsButtonClicked() // Add this method
    {
        cardManager.SetActive(true);
        switchTurnsButton.gameObject.SetActive(false);
    }
}
