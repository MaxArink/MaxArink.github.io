using UnityEngine;

public class PlayersTurnPhaseManager : MonoBehaviour
{

}

public enum TurnPhase
{
    DrawCharacterCardPhase,
    DrawCardPhase,
    AssignCardPhase,
    OptionsPhase
}