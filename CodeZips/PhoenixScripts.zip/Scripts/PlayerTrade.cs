using TMPro;
using UnityEngine;
using System.Collections.Generic;

public class PlayerTrade : MonoBehaviour
{
    // verander van dropdown naar een ui button field
    private Beurten _beurten => GetComponent<Beurten>();

    [SerializeField] private TMP_Dropdown _dropdown;

    private void Start()
    {
        if (_beurten != null) _beurten.OnTurnChanged += UpdateTradeDropdown;

        UpdateTradeDropdown();    
    }

    public void UpdateTradeDropdown()
    {
        _dropdown.options.Clear();

        //foreach (KeyValuePair<int, PlayerInformation> player in GameManager.instance.PlayerInfo)
        //{
        //    int id = player.Key;
        //    PlayerInformation playerInformation = player.Value;

        //    if (!playerInformation.Turn)
        //    {
        //        TMP_Dropdown.OptionData newOption = new TMP_Dropdown.OptionData(GameManager.instance.PlayerNames[id]);
        //        _dropdown.options.Add(newOption);
        //    }
        //}
        for (int i = 0; i < GameManager.instance.PlayerInfo.Count; i++)
        {
            PlayerInformation playerInformation = GameManager.instance.PlayerInfo[i];

            if (!playerInformation.Turn)
            {
                TMP_Dropdown.OptionData newOption = new TMP_Dropdown.OptionData(GameManager.instance.PlayerInfo[i].Name);
                _dropdown.options.Add(newOption);
            }
        }

        _dropdown.captionText.text = "Ruil";

        _dropdown.RefreshShownValue();
    }
}