using UnityEngine;
using UnityEngine.UI;
using System.Collections.Generic;

[System.Serializable]
public class CountdownSettings
{
    [SerializeField] private Image _radialFillImage;
    [SerializeField] private Slider _slider;

    public Image RadialFillImage
    {
        get => _radialFillImage;
        private set => _radialFillImage = value;
    }

    public Slider Sliders
    {
        get => _slider;
        private set => _slider = value;
    }
}

/// <summary>
/// Slechte code kijk er maar niet naar
/// </summary>
[RequireComponent(typeof(Beurten),typeof(FaseSysteem))]
public class Countdown : MonoBehaviour
{
    private Beurten _beurten => GetComponent<Beurten>();
    private FaseSysteem _fase => GetComponent<FaseSysteem>();

    [Header("UI Settings")]
    [SerializeField] private CountdownSettings _turnCountdown;
    [SerializeField] private CountdownSettings _phaseCountdown;

    [Header("Timer Settings")]
    [SerializeField] private float _turnTimeInMinutes = 2; // preset
    [SerializeField] private float _phaseTimeInMinutes = 20;
    private float _turnTimer; // used
    private float _phaseTimer;

    /// <summary>
    /// Gets the round time in seconds based on the value in minutes.
    /// </summary>
    public float TurnTimer
    {
        get => _turnTimeInMinutes * 60;
        private set => _turnTimeInMinutes *= value / 60;
    } 
    public float PhaseTimer
    {
        get => _phaseTimeInMinutes * 60;
        private set => _phaseTimeInMinutes *= value / 60;
    } 

    private void Start()
    {
        if (_beurten != null) 
            _beurten.OnTurnChanged += SetTurnTimer;

        if (_fase != null)
            _fase.OnPhaseChanged += SetPhaseTimer;

        _turnCountdown.RadialFillImage.fillAmount = 1f;
        _turnCountdown.Sliders.onValueChanged.AddListener(UpdateTurnRadialFill);

        _phaseCountdown.RadialFillImage.fillAmount = 1f;
        _phaseCountdown.Sliders.onValueChanged.AddListener(UpdatePhaseRadialFill);

        SetTurnTimer();
        SetPhaseTimer();
    }

    private void Update()
    {
        _turnTimer -= Time.deltaTime;
        _phaseTimer -= Time.deltaTime;

        float turnFillAmount = _turnTimer / TurnTimer;
        _turnCountdown.RadialFillImage.fillAmount = turnFillAmount;

        float phaseFillAmount = _phaseTimer / PhaseTimer;
        _phaseCountdown.RadialFillImage.fillAmount = phaseFillAmount;

        if (_turnTimer <= 0)
        {
            _beurten.Continue();
        }

        if (_phaseTimer <= 0) 
        { 
            // logica voor beurt te beindigen
            _fase.NextPhase();
        }
    }

    public void SetTurnTimer()
    {
        _turnTimer = TurnTimer;
    }
    public void SetPhaseTimer()
    {
        _phaseTimer = PhaseTimer;
    }

    private void UpdateTurnRadialFill(float pFillAmount)
    {
        _turnCountdown.RadialFillImage.fillAmount = pFillAmount;
    }

    private void UpdatePhaseRadialFill(float pFillAmount)
    {
        _phaseCountdown.RadialFillImage.fillAmount = pFillAmount;
    }
}